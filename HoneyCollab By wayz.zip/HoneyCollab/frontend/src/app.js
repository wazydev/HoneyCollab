import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [honeypots, setHoneypots] = useState([]);
  const [newHoneypot, setNewHoneypot] = useState({ name: '', type: '', description: '' });

  useEffect(() => {
    fetch('/honeypots')
      .then(response => response.json())
      .then(data => setHoneypots(data));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewHoneypot(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('/honeypots', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(newHoneypot)
    })
    .then(response => response.json())
    .then(data => {
      setHoneypots([...honeypots, data]);
      setNewHoneypot({ name: '', type: '', description: '' });
    });
  };

  return (
    <div className="App">
      <h1>HoneyNet Collaborative Platform</h1>
      <form onSubmit={handleSubmit}>
        <input type="text" name="name" value={newHoneypot.name} onChange={handleChange} placeholder="Name" required />
        <input type="text" name="type" value={newHoneypot.type} onChange={handleChange} placeholder="Type" required />
        <input type="text" name="description" value={newHoneypot.description} onChange={handleChange} placeholder="Description" />
        <button type="submit">Add Honeypot</button>
      </form>
      <ul>
        {honeypots.map(hp => (
          <li key={hp.id}>{hp.name} - {hp.type}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
