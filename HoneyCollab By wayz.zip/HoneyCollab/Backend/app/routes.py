from flask import request, jsonify
from . import db
from .models import HoneyPot
from . import create_app

app = create_app()

@app.route('/honeypots', methods=['GET', 'POST'])
def manage_honeypots():
    if request.method == 'POST':
        data = request.json
        new_honeypot = HoneyPot(
            name=data['name'],
            type=data['type'],
            description=data['description']
        )
        db.session.add(new_honeypot)
        db.session.commit()
        return jsonify({'message': 'Honeypot created!'}), 201
    
    honeypots = HoneyPot.query.all()
    return jsonify([{'id': hp.id, 'name': hp.name, 'type': hp.type, 'description': hp.description} for hp in honeypots])
