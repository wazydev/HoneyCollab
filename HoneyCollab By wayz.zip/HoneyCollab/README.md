# HoneyNet Collaborative Platform

## Description
Une plateforme collaborative pour le déploiement, la surveillance et l'analyse des honeypots en temps réel.

## Configuration
Assurez-vous d'avoir Docker et Docker Compose installés.

## Installation
Clonez ce dépôt et naviguez dans le répertoire principal.

```bash
git clone https://github.com/votre-utilisateur/honeycollab.git
cd honeycollab

npx create-react-app frontend
cd frontend

docker-compose up --build

Accédez au frontend à l'adresse http://localhost:3000 et à l'API backend à http://localhost:5000.

Fonctionnalités
Déploiement facile de honeypots
Surveillance et collecte de données en temps réel
Analyse et visualisation des attaques
Partage et collaboration entre chercheurs



#Entierement dev par Wayz

/** !!Pensez a attribuer les droits de lancement a vos fichiers **/